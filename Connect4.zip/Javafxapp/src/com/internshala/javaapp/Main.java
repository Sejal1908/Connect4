package com.internshala.javaapp;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.text.html.Option;
import java.util.Optional;

public class Main  extends Application {

    public static void main(String[] args) {
        System.out.println("Main");
        launch(args);
    }

    @Override
    public void init() throws Exception {
        System.out.println("init");// initialize the application
        super.init();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        System.out.println("Start");//starts the application
        FXMLLoader loader = new FXMLLoader(getClass().getResource("app_layout.fxml")); //connects this file to fxml file
        VBox rootNode = loader.load();//loads the fxml file
        MenuBar menuBar = createMenu();
        rootNode.getChildren().add(0, menuBar);




        Scene scene = new Scene(rootNode);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Temperature converter tool");
        primaryStage.show();
    }

    public MenuBar createMenu() {
        //File Menu
        Menu  fileMenu = new Menu("File");
        MenuItem newMenuItem = new MenuItem("New");

        newMenuItem.setOnAction(event -> {
            System.out.println("New Menu Item Clicked");
        });

        SeparatorMenuItem separatorMenuItem = new SeparatorMenuItem();
        MenuItem quitMenuItem = new MenuItem("Quit");

        quitMenuItem.setOnAction(event -> {
            Platform.exit();
            System.exit(0);
        });
        fileMenu.getItems().addAll(newMenuItem,separatorMenuItem, quitMenuItem);


        //Help Menu
        Menu helpMenu =  new Menu("Help");
        MenuItem aboutApp = new MenuItem("About");
        
        aboutApp.setOnAction(event -> aboutApp());
        helpMenu.getItems().addAll(aboutApp);
        
        

            
        
        


        //Menu Bar
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(helpMenu,fileMenu);

        return menuBar;

    }

    private void aboutApp() {
        Alert alertDailog = new Alert(Alert.AlertType.WARNING);
        alertDailog.setTitle("My First desktop app");
        alertDailog.setHeaderText("Learning javafx");
        alertDailog.setContentText("I am just a beginner but soon I will be pro and start developing awesome apps");
        ButtonType yesBtn = new ButtonType("Yes");
        ButtonType noBtn = new ButtonType("No");
        alertDailog.getButtonTypes().setAll(yesBtn, noBtn);
        Optional<ButtonType> clickBtn = alertDailog.showAndWait();

        if (clickBtn.isPresent() && clickBtn.get() == yesBtn) {
            System.out.println("Yes Button Clicked!");
        } else {
            System.out.println("No Button Clicked!");
        }

    }


    @Override
    public void stop() throws Exception {
        System.out.println("stop");//stops the application
        super.stop();
    }
}


